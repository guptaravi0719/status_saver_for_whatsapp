package io.flutter.plugins.shared_preferences_web;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/** SharedPreferencesWebPlugin */
public class SharedPreferencesWebPlugin implements FlutterPlugin {
  @Override
  public void onAttachedToEngine(FlutterPluginBinding flutterPluginBinding) {}

  public static void registerWith(Registrar registrar) {}

  @Override
  public void onDetachedFromEngine(FlutterPluginBinding binding) {}
}
